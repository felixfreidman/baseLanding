const specialButtons = document.querySelectorAll(".staffCard__button");
specialButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setTimeout(function () {
      button.classList.add("addedSpecial");
      button.textContent = "Добавлено";
    }, 1000);
  });
});

let topSlider = new KeenSlider(".topSlider", {
  loop: false,
  breakpoints: {
    "(min-width: 0px)": {
      slides: { perView: 2.1, spacing: 16 },
    },
    "(min-width: 961px)": {
      slides: { perView: 5, spacing: 20 },
    },
  },
});

let brandSlider = new KeenSlider(".brandSlider", {
  loop: false,
  breakpoints: {
    "(min-width: 0px)": {
      slides: { perView: 2.1, spacing: 16 },
    },
    "(min-width: 961px)": {
      slides: { perView: 5, spacing: 20 },
    },
  },
});
